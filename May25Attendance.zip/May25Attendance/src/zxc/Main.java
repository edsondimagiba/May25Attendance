package zxc;

public class Main {
	
	public static void main(String[] args) {
		Car ToyotaVios = new Car();
		
		System.out.println("Horse Power" + " " + ToyotaVios.horsepower);
		System.out.println("Paint" + " " + ToyotaVios.color);
		System.out.println("Cost" + " " + ToyotaVios.cost);
		
		ToyotaVios.tireType();
		ToyotaVios.park();
		ToyotaVios.stop();
	}

}
