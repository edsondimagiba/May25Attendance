package zxc;

public class Vehicle {
	int horsepower = 180;
	String color = "Violet";
	double cost = 1500000.00;
	
	void stop() {
		System.out.println("Stop");
	}

}
