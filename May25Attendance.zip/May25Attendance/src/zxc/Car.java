package zxc;

public class Car {
	
	public int horsepower = 180;
	public String color = "Violet";
	public double cost = 1500000.00;
	
	void tireType() {
		System.out.println("Off-Road Tire");
		
	}
	void park() {
		System.out.println("Toyota Vios is Running");
		
	}
	void stop () {
		System.out.println("Stop!");
	}

}
