package Boat;

public class Boat {
	String name = "My Cruiser";
	String sailcolor = "WHITE";
	public String speed = "120";
	public String color = "White";
	public String price = "12,312,218.00";
	 
	 
	void stop() {
		 //super.stop();//
		 System.out.println("The boat is reducing speed");        
	    }
	 
	void Float() {
		 System.out.println("Yacht is starting to Float!");
	 }
	
}


