package Boat;


public class Main {

	public static void main(String[] args) {
	Boat cruiser = new Boat();
		
	cruiser.Float();
	cruiser.stop();
		
		System.out.println("\nMy Cruiser Information:");
        System.out.println("Speed: " + cruiser.speed + " km");
        System.out.println("Color: " + cruiser.color);
        System.out.println("Price: $" + cruiser.price);
        System.out.println("Name: " + cruiser.name);
        System.out.println("Main Color: " + cruiser.sailcolor);

	}

}
