package Boat;

public class Vehicle {
	
		String speed = "120";
		String color = "White";
		String price = "12,312,218.00";
			

			 void stop() {
				System.out.println("The boat has stopped!");
			}
	}
