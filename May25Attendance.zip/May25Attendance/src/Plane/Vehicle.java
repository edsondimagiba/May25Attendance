package Plane;

public class Vehicle {
	String speed = "320km";
	String color = "White";
	String price = "54,351,320.00";
		

		 void stop() {
			System.out.println("The plane is landing!");
		}
}
