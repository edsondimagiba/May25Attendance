package Plane;



public class Main {
	public static void main(String[] args) {
		Plane plane = new Plane();
		
		plane.fly();
		plane.stop();
		
		System.out.println("\nU-2 My Plane specs:");
        System.out.println("Speed: " + plane.speed + " km/h");
        System.out.println("Color: " + plane.color);
        System.out.println("Price: P" + plane.price);
        System.out.println("Name: " + plane.name);
        System.out.println("Wingspan: " + plane.wingspan);

	}

}
