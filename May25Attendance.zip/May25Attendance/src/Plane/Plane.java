package Plane;

public class Plane {
	
	String name = "My Plane";
	String wingspan = "30 m";
	public String color = "320km";
	public String speed = "White";
	public String price = "54,351,320.00";
	 
	 
	void stop() {
		 //super.stop();//
		 System.out.println("My plane is landing!");	        
	    }
	 
	void fly() {
		 System.out.println("My Plane is flying!");
	 }
}
